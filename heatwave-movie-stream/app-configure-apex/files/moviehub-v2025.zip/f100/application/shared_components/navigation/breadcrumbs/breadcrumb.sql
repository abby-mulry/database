prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(16555259918600334)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8619206779674290)
,p_short_name=>'Hello, Lisa'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8619566495676906)
,p_short_name=>'Hello, James'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8623892441710787)
,p_short_name=>'Halloween Movie --> Recommended Users'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8627496158721294)
,p_short_name=>'Top Trending Movie  --> Recommended Users'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8639498487745228)
,p_short_name=>'Analytics Dashboard'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16555459044600335)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16905307963600712)
,p_short_name=>'Admin Config'
,p_long_name=>'Administration Configuration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21975776770271164)
,p_short_name=>'Admin Views'
,p_long_name=>'Administration Views'
,p_link=>'f?p=&APP_ID.:10005:&SESSION.::&DEBUG.:::'
,p_page_id=>10005
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(22499302822183855)
,p_short_name=>'My Profiles'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
,p_security_scheme=>'!'||wwv_flow_imp.id(16844170522600560)
);
wwv_flow_imp.component_end;
end;
/
