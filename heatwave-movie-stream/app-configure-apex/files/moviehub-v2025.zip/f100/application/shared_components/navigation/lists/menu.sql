prompt --application/shared_components/navigation/lists/menu
begin
--   Manifest
--     LIST: Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(16555744296600337)
,p_name=>'Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16852192942600586)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8647889245027357)
,p_list_item_display_sequence=>10010
,p_list_item_link_text=>'My Profiles'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(16852192942600586)
,p_security_scheme=>'!'||wwv_flow_imp.id(16844170522600560)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21970029508271137)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Admin Views'
,p_list_item_link_target=>'f?p=&APP_ID.:10005:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(16844170522600560)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10005'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8643717422790385)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Holiday Movie'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-film'
,p_parent_list_item_id=>wwv_flow_imp.id(21970029508271137)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21180577849696450)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Top Trending Movie'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-film'
,p_parent_list_item_id=>wwv_flow_imp.id(21970029508271137)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8643963701793597)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Analytics Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_parent_list_item_id=>wwv_flow_imp.id(21970029508271137)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16904339821600710)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Admin Config'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(16844170522600560)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
