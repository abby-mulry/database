prompt --application/pages/page_10005
begin
--   Manifest
--     PAGE: 10005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>10005
,p_name=>'Administration Views'
,p_alias=>'ADMINISTRATION-VIEWS'
,p_step_title=>'Administration Views'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(16845437803600566)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body {',
'background-image: url(#APP_IMAGES#BG.jpg);',
'background-repeat:  no-repeat;',
'background-attachment: fixed;',
'background-size:  cover;',
'}',
'',
'body .t-Login-region {',
'    background-color: rgba(255,255,255,0.51);',
'    border-radius: 25px;',
'}',
'',
'body .t-Login-logo {',
'   background-image: url(#APP_IMAGES#logo.png);',
'   background-color: rgba(255,255,255,0);',
'   background-repeat:no-repeat; ',
'   background-position: center center; ',
'   width: 210px;',
'   height: 115px; ',
'}',
'',
' #P9999_USERNAME, #P9999_PASSWORD {',
'   background-color: #ffffff;',
'   border-bottom-color: #1e90ff;',
'   border-width: 0 0 3px 0;',
'   border-radius: 25px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(16844170522600560)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The administration page allows application owners (Administrators) to configure the application and maintain common data used across the application.',
'By selecting one of the available settings, administrators can potentially change how the application is displayed and/or features available to the end users.</p>',
'<p>Access to this page should be limited to Administrators only.</p>'))
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20231017042201'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21899586033633832)
,p_plug_name=>'Holiday Movie: Recommended Users'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_column=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21899931164633836)
,p_plug_name=>'Top Trending Movie: Recommended Users'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_plug_display_column=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22516639754730513)
,p_plug_name=>'Analytics Dashboards'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16658618210600400)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_column=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30333342307220542)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16670965546600409)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16555259918600334)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16733428132600444)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21899719632633833)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(21899586033633832)
,p_button_name=>'Holiday'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconRight:t-Button--hoverIconPush:t-Button--pill:t-Button--stretch:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(16731846543600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'GO to Holiday Movie -->'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-lg fa-film'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21900069772633837)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(21899931164633836)
,p_button_name=>'Trending'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconRight:t-Button--hoverIconPush:t-Button--pill:t-Button--stretch:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(16731846543600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'GO to Top Trending Movie -->'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-lg fa-film'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22517062982730517)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(22516639754730513)
,p_button_name=>'Dashboards'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconRight:t-Button--hoverIconPush:t-Button--pill:t-Button--stretch:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(16731846543600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'GO to Dashboards -->'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-lg fa-dashboard'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22516768380730514)
,p_name=>'P10005_NEW_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(22516639754730513)
,p_source=>'#APP_FILES#icons/graphs.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22516900377730515)
,p_name=>'P10005_NEW_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21899586033633832)
,p_use_cache_before_default=>'NO'
,p_source=>'#APP_FILES#icons/Pumpkins.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22516950581730516)
,p_name=>'P10005_NEW_3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21899931164633836)
,p_source=>'#APP_FILES#icons/trends.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(16729275947600439)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp.component_end;
end;
/
