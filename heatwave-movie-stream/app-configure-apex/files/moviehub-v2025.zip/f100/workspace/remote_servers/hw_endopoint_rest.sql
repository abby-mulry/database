prompt --workspace/remote_servers/hw_endopoint_rest
begin
--   Manifest
--     REMOTE SERVER: hw_endopoint_rest
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(17064182168279363)
,p_name=>'hw_endopoint_rest'
,p_static_id=>'hw_endopoint_rest'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('hw_endopoint_rest'),'https://sql.dbtools.mx-queretaro-1.oci.oraclecloud.com/20201005/ords/ocid1.databasetoolsconnection.oc1.mx-queretaro-1.amaaaaaacicuulya5ogj6fzkqyqcb5ecba6u4bhqtqocytyvj6ix3y6aci7a')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('hw_endopoint_rest'),'')
,p_server_type=>'REMOTE_SQL'
,p_ords_version=>'23.2.3.r2421937'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('hw_endopoint_rest'),'UTC')
,p_credential_id=>wwv_flow_imp.id(7268969782615705)
,p_remote_sql_database_type=>'MYSQL'
,p_remote_sql_database_info=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "database_product_name":"MySQL"',
'   ,"database_product_version":"8.1.0-u4-cloud"',
'   ,"database_major_version":8',
'   ,"database_minor_version":1',
'   ,"env":{',
'        "defaultTimeZone":"UTC"',
'       ,"ordsVersion":"23.2.3.r2421937"',
'    }',
'}',
''))
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('hw_endopoint_rest'),'movies')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('hw_endopoint_rest'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
